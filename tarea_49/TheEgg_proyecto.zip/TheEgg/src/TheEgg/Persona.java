package TheEgg;

/**
 * @author Oscar Rojo
 * @version 1.0
 *
 * Esta clase representa a la persona.
 */
public class Persona {
	
	/**
	 * Nombre de la persona
	 */
    public String nombre;
	
	/**
	 * EDAD de la persona
	 */
    public int edad;
	
	/**
	 * DNI de la persona
	 */
    public int dni;
    
	/**
	 * Default constructor:
	 * 	name = "Lorem Ipsum".
	 *  edad = 44
	 *  dni = 21522511
	 *  @throws Exception is never thrown because the values of the fields are correct	  
	 *
	 * public Persona() throws Exception {this("Oscar", 44, 44122566);}
	 */
    
    /**
	 * Parameterized constructor
	 * @param name Persona's name (max. 70 chars)
	 * @param edad Persona's edad (>= 0 years old)
	 * @param dni Persona's dni

	 */
    public Persona(String nombre, int edad, int dni) {
        setNombre(nombre);
        setEdad(edad);
        setDni(dni);
    }

	/**
	 * Getter of "nombre"
	 * @return Nombre de la persona
	 */
    public String getNombre() {
        return this.nombre;
    }
    
	/**
	 * Setter of "nombre"
	 * @param nombre New nombre que queremos asignar a la persona
	 */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

	/**
	 * Getter of "edad"
	 * @return edad Persona
	 */
    public int getEdad() {
        return this.edad;
    }

	/**
	 * Setter of "edad"
	 * @param edad New edad que queremos asignar a persona
	 * @throws Exception When the new edad has more les 0 age
	 */
    public void setEdad(int edad) {
        if(edad < 0) {	
        	System.out.println("[ERROR] Edad incorrecta");
 		}else {
 			this.edad = edad;
 		}
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String calcularLetra() {
        String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
        //La letra correspondiente sera el resto de la division del numero del DNI entre las 23 posibilidades que hay
        char letra = letras.charAt(dni % letras.length());
        String dniEntero = "" + letra;
        return dniEntero;
    }

    /**
     * @param args
     * @throws Exception 
     */
    public static void main(String[] args) {

        Persona[] personas = new Persona[5];
        personas[0] = new Persona("Juan  ", 53, 12345678);
        personas[1] = new Persona("Gema  ", 42, 23456789);
        personas[2] = new Persona("Javier", 20, 34567891);
        personas[3] = new Persona("Marina", 17, 45678912);
        personas[4] = new Persona("Danko ", 10, 56789123);
        for (Persona persona : personas) {
        	if (persona.edad >= 18) {
        		System.out.println("El dni es " + persona.dni + "" + persona.calcularLetra() + " su nombre es " + persona.nombre + " y su edad es de " + persona.edad + ", es mayor de edad");
        	} else {
        		System.out.println("El dni es " + persona.dni + "" + persona.calcularLetra() + " su nombre es " + persona.nombre + " y su edad es de " + persona.edad + ", es menor de edad");
        	} 
        }
    }
}

