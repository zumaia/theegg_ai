package TheEgg;

/**
 * @author Oscar Rojo
 * @version 1.0
 *
 * Esta clase representa a la cuenta.
 */
public class Cuenta {
	
	/**
	 * Titular de la cuenta
	 */
	private static Persona titular;
	
	/**
	 * saldo de la cuenta
	 */
	private static double saldo;
	
	public Cuenta (Persona p, double saldo) {
		setSaldo(saldo);
	}

	public void setSaldo(double saldo) {
		Cuenta.saldo = saldo;
	}

	public static Persona getTitular() {
		return titular;
	}

	public void setTitular(Persona titular) {
		Cuenta.titular = titular;
	}
	
	public void ingresar(double cantidad) {
		saldo = saldo + cantidad;
	}

	public void retirar(double cantidad)  {
		if(saldo < cantidad) {	
 			System.out.println("[ERROR] No hay saldo");
 		}else {
 			saldo = saldo - cantidad;
 		}
	}
	
	public static double getSaldo(){
		return saldo;
	}
	
	 public static void main(String[] args) {
	        Persona[] personas = new Persona[5];
	        personas[0] = new Persona("Juan  ", 53, 12345678);
	        personas[1] = new Persona("Gema  ", 42, 23456789);
	        personas[2] = new Persona("Javier", 20, 34567891);
	        personas[3] = new Persona("Marina", 17, 45678912);
	        personas[4] = new Persona("Danko ", 10, 56789123);
	        Cuenta[] cuentas = new Cuenta[5];
	        cuentas[0] = new Cuenta(personas[0] , 0.0);
	        cuentas[1] = new Cuenta(personas[1] , 0.0);
	        cuentas[2] = new Cuenta(personas[2] , 0.0);
	        cuentas[3] = new Cuenta(personas[3] , 0.0);
	        cuentas[4] = new Cuenta(personas[4] , 0.0);
	        
	        for (Persona persona : personas) {
	            System.out.println("D. " + persona.nombre + " tiene una cuenta con saldo de " + Cuenta.saldo+ "\n");
	        }
            System.out.println("\n");
            System.out.println("\n");
            
	        cuentas[0].ingresar(400);
	        System.out.println("El nuevo saldo es "  + getSaldo());
	        cuentas[0].retirar(550);
	        System.out.println("El nuevo saldo es "  + getSaldo());
	        cuentas[0].ingresar(100);
	        System.out.println("El nuevo saldo es "  + getSaldo());
	        cuentas[0].retirar(250);
	        System.out.println("El nuevo saldo es "  + getSaldo());
	        cuentas[0].ingresar(800);
	        System.out.println("El nuevo saldo es "  + getSaldo());
	        cuentas[0].retirar(1080);
	        System.out.println("El nuevo saldo es "  + getSaldo());
	        cuentas[0].ingresar(10000);
	        System.out.println("El nuevo saldo es "  + getSaldo());
	        cuentas[0].retirar(0);
	        System.out.println("El nuevo saldo es "  + getSaldo());
	        cuentas[0].ingresar(9000);
	        System.out.println("El nuevo saldo es "  + getSaldo());
	        cuentas[0].retirar(100000);
	        
            System.out.println("\n");
        	System.out.println("D. " + personas[0].nombre + " tiene una cuenta con saldo de " + getSaldo());
	       
	        
	  
	 }

}
